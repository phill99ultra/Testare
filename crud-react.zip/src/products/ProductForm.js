import React from 'react'
import {Form, Button} from 'react-bootstrap'


class ProductForm extends React.Component{
    constructor(){
        super()
        this.state = {
            validated: false
        }
    }
    handleSubmit(event) {
        event.preventDefault(); // nu permite browserului sa faca submit
        alert();
    }
    render(){
        return(
            <div id="product-form">
                <Form className='container'onSubmit={e => this.handleSubmit(e)}>
                    <Form.Group>
                        <Form.Control type="text" placeholder="Product Name" size='lg'/>
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="Product Name" size='lg'/>
                    </Form.Group> 
                    <Form.Group>
                        <Form.Control type="text" placeholder="Product Name" size='lg'/>
                    </Form.Group>
                    <Form.Group>
                        <Form.Control type="text" placeholder="Product Name" size='lg'/>
                    </Form.Group>
                    <Button type='submit' variant='danger'>Save</Button>        
                </Form>    
            </div>
        )
    }
}

export default ProductForm